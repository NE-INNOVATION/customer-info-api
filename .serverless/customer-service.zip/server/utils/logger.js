let Logger = (() => {
  const createLogger = () => {
    
  }
  return {
    createLogger: createLogger,
  };
})();
