module.exports = {
    app: require('./app')
}